#!/bin/bash

# exécutable en ligne de commande sous linux pour compiler le code latex correspondant au rapport du master ECD
# attention, ce code devra probablement être modifié en fonction de votre environnement de développement

bibtex rapport_exemple
latex rapport_exemple.tex
bibtex rapport_exemple
latex rapport_exemple.tex
bibtex rapport_exemple
latex rapport_exemple.tex

dvips -t a4 rapport_exemple.dvi -o rapport_exemple.ps

ps2pdf rapport_exemple.ps

